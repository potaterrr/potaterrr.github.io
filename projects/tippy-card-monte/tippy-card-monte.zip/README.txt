TIPPY CARD MONTE · V1.3.6
===========================

A pixel card monte game made for Open Arcade.

MODES
- Classic: 16 rounds, 7 stages, finish above 0p to win.
- Bet: infinite rounds, 16 cards. Bet 5/10/25/50/100p, watch Tippy, then pick Tippy. A wrong pick loses your stake. Cash out the pot; debt is allowed.
- Endless: no fail. Start at 16 cards and climb. Every 4 depths pauses for a checkpoint bonus and a perk. Best depth is the record.
- Daily: one seeded 16-round shuffle per day. Best score for today is saved.
- Blitz: 8 fast rounds. Score chase.
- Zen: 16 rounds, no fail, no debt pressure, slower peeks.

HOW TO PLAY
- Watch where Tippy hides.
- Follow the shuffle.
- Pick the card with Tippy to bank coins.
- A wrong pick costs 5p and resets your streak.
- Streak wins pay more: +5p, +10p, +15p, +20p, +25p, and keeps climbing with no cap.
- Score can go negative. Finish above 0p to win Classic/Daily/Blitz.
- 16 rounds in Classic. The deck grows from 3 cards to 16.
- All 16 picks correct is a BIG WIN.
- Endless checkpoints offer one of three perks: Longer Peek, Fewer Shuffles, Slow Hands, Coin Purse, Safety Net, Streak Guard.
- 15 medals unlock across the modes and are saved in this browser.

CONTROLS
- Mouse / touch: pick a card.
- Keyboard: Tab to a card and press Enter, or use 1-9, 0, Q, W, E, R, T, Y, U.
- M: mute or unmute.
- F: toggle fullscreen.
- Endless: use CASH OUT in the HUD (once) or the checkpoint CASH OUT button to end the run and record your depth.
- Bet mode: choose a bet, watch Tippy during the peek, follow the shuffle, then pick Tippy. A wrong pick loses the stake. Cash out the pot to bank it; debt is allowed. Rounds never stop, so exit when you are done.
- Fullscreen: press the FULLSCREEN button or F. On touch devices the game asks for landscape so the table fills the screen.
- Exit: press the EXIT button in the HUD to return straight to the home/title screen. In Bet mode, any unbanked pot is forfeited, so cash out first if you want it.

CREDITS
- Game and pixel art: Tippy Card Monte.
- Font: Press Start 2P by CodeMan38, SIL Open Font License 1.1 (see OFL.txt).
- Ending illustrations: supplied with the project.
